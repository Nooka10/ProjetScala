create definer = `beerPass`@`localhost` trigger `REMOVE ADDRESS BEFORE DELETE`
	before DELETE
	on `COMPANY`
	for each row
	DELETE FROM ADDRESS WHERE ADDRESS.ID = OLD.ADDRESS_ID;

