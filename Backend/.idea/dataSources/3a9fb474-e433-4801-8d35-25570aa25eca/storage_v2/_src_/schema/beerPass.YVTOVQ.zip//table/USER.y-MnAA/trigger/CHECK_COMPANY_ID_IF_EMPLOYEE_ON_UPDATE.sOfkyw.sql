create definer = `beerPass`@`localhost` trigger `CHECK COMPANY_ID IF EMPLOYEE ON UPDATE`
	before UPDATE
	on `USER`
	for each row
BEGIN
	IF NEW.USER_TYPE = 'EMPLOYEE' THEN
		IF NEW.COMPANY_ID IS NULL THEN
			SIGNAL SQLSTATE '45000' set message_text = 'Error : an employee must have a companyId';
		END IF;
	END IF;
END;

