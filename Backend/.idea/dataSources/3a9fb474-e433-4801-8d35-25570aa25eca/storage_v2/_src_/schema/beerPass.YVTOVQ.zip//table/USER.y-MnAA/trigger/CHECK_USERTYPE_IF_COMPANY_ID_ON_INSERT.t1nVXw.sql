create definer = `beerPass`@`localhost` trigger `CHECK USERTYPE IF COMPANY_ID ON INSERT`
	before INSERT
	on `USER`
	for each row
BEGIN
	IF NEW.COMPANY_ID IS NOT NULL THEN
		SET NEW.USER_TYPE = 'EMPLOYEE';
	END IF;
END;

